mapbox-studio-default-style + nutiteq features
===========================
Style for Nutiteq vt-s
